
Alarm Clock App 🕰️
Task - Android App Development Internship in CodSoft
This Android application allows users to set and manage alarms, ensuring they stay on schedule.

✨ Features
- Set multiple alarms with custom times and labels
- Simple and clean UI
- Works offline
- Built using Java in Android Studio

🛠 Tech Stack
- Java
- Android Studio
- ConstraintLayout
- Git & GitHub

 Developed by *Tarun Tejasvi VP*
 📅 August 2025 
 🎓 CodSoft Internship 

Let me know if this meets your requirements or if you need further adjustments!
